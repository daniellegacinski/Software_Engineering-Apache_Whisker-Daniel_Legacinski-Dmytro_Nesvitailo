// Copyright (c) 2026 Dima Nesvitajlo
// License: MIT
function showInfo(){document.getElementById("output").textContent="Demo distribution for Apache Whisker license documentation.";}
