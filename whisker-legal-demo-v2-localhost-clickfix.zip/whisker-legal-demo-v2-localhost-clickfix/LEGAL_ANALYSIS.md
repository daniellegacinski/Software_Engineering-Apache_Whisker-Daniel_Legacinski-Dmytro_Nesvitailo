# Legal and technical analysis - V2

This project demonstrates license compliance documentation for an application containing own files and third-party components.

The demo contains MIT-licensed own files, an MIT third-party helper and an Apache-2.0 third-party component. The GPL-like file is not included in the distribution and is used only as a risk example.

The first console version runs Apache Whisker directly through Maven. This V2 localhost version is a stable web demonstration that creates LICENSE and NOTICE files from the same project metadata and allows viewing all project files through buttons.

Apache Whisker does not choose a license and does not replace legal advice. It helps keep license metadata structured and supports generation of licensing documentation.
