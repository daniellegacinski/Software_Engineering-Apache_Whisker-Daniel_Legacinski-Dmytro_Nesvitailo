/* This file is NOT part of distribution. It is only an example of GPL/copyleft risk. */
int risky_example(){return 1;}
