$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "Starting Apache Whisker V2 Localhost click-fix..." -ForegroundColor Cyan
Write-Host "URL: http://localhost:8080" -ForegroundColor Green
.\server\server.ps1
