$ErrorActionPreference = "Stop"
$ProjectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location $ProjectRoot
$Port = 8080
$Prefix = "http://localhost:$Port/"
$global:StopServer = $false

function SendText($Context, [string]$Text, [string]$ContentType) {
    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $Context.Response.ContentType = $ContentType
    $Context.Response.ContentLength64 = $Bytes.Length
    $Context.Response.OutputStream.Write($Bytes, 0, $Bytes.Length)
    $Context.Response.OutputStream.Close()
}
function HtmlEscape([string]$Text) { return [System.Net.WebUtility]::HtmlEncode($Text) }
function ReadFile([string]$Rel) {
    $Path = Join-Path $ProjectRoot $Rel
    if (!(Test-Path $Path)) { return "File not found: $Path" }
    return Get-Content $Path -Raw -Encoding UTF8
}
function ProjectTreeText {
    return ((Get-ChildItem $ProjectRoot -Recurse -File | Where-Object { $_.FullName -notlike "*\target\*" } | Sort-Object FullName | ForEach-Object { $_.FullName.Substring($ProjectRoot.Path.Length + 1) }) -join "`r`n")
}
function GenerateDocs {
    $OutDir = Join-Path $ProjectRoot "generated-legal-docs"
    if (!(Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }
    $Now = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $License = @"
LICENSE
=======

Generated at: $Now
Generator mode: stable localhost V2 demo

Primary project license:
MIT License
Copyright (c) 2026 Dima Nesvitajlo

This distribution contains own project files and third-party resources.

OWN PROJECT FILES
-----------------
- distribution/index.html       MIT License       Dima Nesvitajlo Student Project
- distribution/app.js           MIT License       Dima Nesvitajlo Student Project
- distribution/style.css        MIT License       Dima Nesvitajlo Student Project

THIRD-PARTY RESOURCES
---------------------
- distribution/third-party/mit-helper.js
  Organisation: Example MIT Author
  License: MIT License
  Obligation: preserve copyright notice and license text.

- distribution/third-party/apache-tool.java
  Organisation: Apache Software Foundation
  License: Apache License, Version 2.0
  Obligation: include Apache License text and attribution information.

MIT LICENSE TEXT
----------------
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files, to deal in the Software
without restriction, including without limitation the rights to use, copy,
modify, merge, publish, distribute, sublicense, and/or sell copies of the
Software, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.

APACHE LICENSE 2.0 NOTE
-----------------------
The demo references Apache License 2.0 for an example third-party component.
The full official license text is available at:
https://www.apache.org/licenses/LICENSE-2.0.txt
"@
    $Notice = @"
NOTICE
======

This product includes example third-party resources.

Apache component:
- distribution/third-party/apache-tool.java
- Organisation: Apache Software Foundation
- License: Apache License, Version 2.0

MIT helper:
- distribution/third-party/mit-helper.js
- Organisation: Example MIT Author
- License: MIT License
"@
    $Log = @"
GENERATION LOG
Generated at: $Now
Mode: stable localhost generator
Result: LICENSE and NOTICE files were created successfully.

Files created:
- generated-legal-docs/LICENSE
- generated-legal-docs/NOTICE
"@
    [System.IO.File]::WriteAllText((Join-Path $OutDir "LICENSE"), $License, [System.Text.Encoding]::UTF8)
    [System.IO.File]::WriteAllText((Join-Path $OutDir "NOTICE"), $Notice, [System.Text.Encoding]::UTF8)
    [System.IO.File]::WriteAllText((Join-Path $OutDir "GENERATION_LOG.txt"), $Log, [System.Text.Encoding]::UTF8)
    return $Log
}
function Page([string]$Title, [string]$Body) {
$Status = if (Test-Path (Join-Path $ProjectRoot "generated-legal-docs\LICENSE")) { "generated" } else { "missing" }
$StatusClass = if ($Status -eq "generated") { "ok" } else { "warn" }
return @"
<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Apache Whisker V2</title><style>
body{margin:0;font-family:Arial;background:#0f172a;color:#e5e7eb}header{padding:30px;background:#020617;border-bottom:1px solid #334155}main{padding:24px;max-width:1150px;margin:auto}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.card{background:#111827;border:1px solid #2563eb;border-radius:18px;padding:20px;margin-bottom:18px}a.button{display:inline-block;text-decoration:none;padding:11px 14px;margin:5px;border:1px solid #60a5fa;border-radius:12px;background:#1f2937;color:#e5e7eb;font-weight:bold}.primary{background:linear-gradient(135deg,#38bdf8,#22c55e)!important;color:#020617!important;border:0!important}.danger{background:#7f1d1d!important}.ok{color:#22c55e}.warn{color:#f59e0b}pre{white-space:pre-wrap;word-break:break-word;background:#020617;border:1px solid #60a5fa;border-radius:14px;padding:15px;max-height:520px;overflow:auto}.pill{display:inline-block;background:#082f49;border:1px solid #0369a1;color:#bae6fd;border-radius:999px;padding:6px 10px;margin:4px}@media(max-width:900px){.grid{grid-template-columns:1fr}}
</style></head><body><header><h1>Apache Whisker V2 Localhost</h1><div>Separate second version with local web interface.</div></header><main><div class="grid"><section class="card"><h2>Panel</h2><p>This version uses normal page links, so every button changes the output reliably.</p><a class="button primary" href="/generate">Generate LICENSE</a><a class="button" href="/view/license">Show LICENSE</a><a class="button" href="/view/notice">Show NOTICE</a><a class="button" href="/view/descriptor">Show descriptor.xml</a><a class="button" href="/view/analysis">Show analysis</a><a class="button" href="/view/matrix">Show license table</a><a class="button" href="/view/pom">Show pom.xml</a><a class="button" href="/tree">Project tree</a><a class="button" href="/open">Open output folder</a><a class="button" href="/view/log">Show generation log</a><a class="button danger" href="/stop">Stop localhost</a><h3>LICENSE status: <span class="$StatusClass">$Status</span></h3><span class="pill">MIT</span><span class="pill">Apache 2.0</span><span class="pill">Third-party</span><span class="pill">License compliance</span></section><section class="card"><h2>Tool status</h2><pre>Stable click-fix mode. No JavaScript is required for buttons.
The first console version can still be used for direct Apache Whisker execution.</pre></section></div><section class="card"><h2>$Title</h2><pre>$Body</pre></section></main></body></html>
"@
}
try {
    Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique | Where-Object { $_ -ne $PID } | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }
} catch {}
$Listener = New-Object System.Net.HttpListener
$Listener.Prefixes.Add($Prefix)
$Listener.Start()
Write-Host "Server started: $Prefix" -ForegroundColor Green
Start-Process $Prefix
while ($Listener.IsListening -and -not $global:StopServer) {
    $Context = $Listener.GetContext(); $Path = $Context.Request.Url.AbsolutePath
    if ($Path -eq "/") { SendText $Context (Page "Output" "Click a button.") "text/html; charset=utf-8" }
    elseif ($Path -eq "/generate") { SendText $Context (Page "BUILD SUCCESS" (HtmlEscape (GenerateDocs))) "text/html; charset=utf-8" }
    elseif ($Path -eq "/view/license") { SendText $Context (Page "generated-legal-docs/LICENSE" (HtmlEscape (ReadFile "generated-legal-docs\LICENSE"))) "text/html; charset=utf-8" }
    elseif ($Path -eq "/view/notice") { SendText $Context (Page "generated-legal-docs/NOTICE" (HtmlEscape (ReadFile "generated-legal-docs\NOTICE"))) "text/html; charset=utf-8" }
    elseif ($Path -eq "/view/log") { SendText $Context (Page "generated-legal-docs/GENERATION_LOG.txt" (HtmlEscape (ReadFile "generated-legal-docs\GENERATION_LOG.txt"))) "text/html; charset=utf-8" }
    elseif ($Path -eq "/view/descriptor") { SendText $Context (Page "descriptor.xml" (HtmlEscape (ReadFile "descriptor.xml"))) "text/html; charset=utf-8" }
    elseif ($Path -eq "/view/analysis") { SendText $Context (Page "LEGAL_ANALYSIS.md" (HtmlEscape (ReadFile "LEGAL_ANALYSIS.md"))) "text/html; charset=utf-8" }
    elseif ($Path -eq "/view/matrix") { SendText $Context (Page "license-matrix.csv" (HtmlEscape (ReadFile "license-matrix.csv"))) "text/html; charset=utf-8" }
    elseif ($Path -eq "/view/pom") { SendText $Context (Page "pom.xml" (HtmlEscape (ReadFile "pom.xml"))) "text/html; charset=utf-8" }
    elseif ($Path -eq "/tree") { SendText $Context (Page "Project tree" (HtmlEscape (ProjectTreeText))) "text/html; charset=utf-8" }
    elseif ($Path -eq "/open") { $Out = Join-Path $ProjectRoot "generated-legal-docs"; if(Test-Path $Out){Invoke-Item $Out; $Msg="Opened: $Out"}else{$Msg="Output folder does not exist. Generate LICENSE first."}; SendText $Context (Page "Open output folder" (HtmlEscape $Msg)) "text/html; charset=utf-8" }
    elseif ($Path -eq "/stop") { SendText $Context (Page "Server stopped" "You can close this browser tab.") "text/html; charset=utf-8"; $global:StopServer=$true }
    else { SendText $Context (Page "404" "Not found") "text/html; charset=utf-8" }
}
$Listener.Stop(); $Listener.Close(); Write-Host "Server stopped." -ForegroundColor Yellow
