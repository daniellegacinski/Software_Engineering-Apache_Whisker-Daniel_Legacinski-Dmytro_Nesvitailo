﻿Apache Whisker Legal Documentation Demo

Cel:
Pokazanie automatycznego generowania dokumentacji licencyjnej aplikacji przy pomocy Apache Whisker.

NajwaÅ¼niejsze pliki:
- descriptor.xml
- pom.xml
- license-matrix.csv
- LEGAL_ANALYSIS.md
- generated-legal-docs

Jak uruchomiÄ‡:
1. WejÅ›Ä‡ do folderu whisker-legal-demo
2. UruchomiÄ‡ scripts\Run-Whisker.ps1
3. SprawdziÄ‡ folder generated-legal-docs

NajwaÅ¼niejsza idea:
Apache Whisker nie tworzy licencji od zera. NarzÄ™dzie generuje dokumentacjÄ™ licencyjnÄ… na podstawie metadanych opisujÄ…cych pliki, organizacje i licencje.