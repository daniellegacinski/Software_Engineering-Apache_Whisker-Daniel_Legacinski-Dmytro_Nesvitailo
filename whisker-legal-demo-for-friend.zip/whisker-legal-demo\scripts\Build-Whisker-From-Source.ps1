﻿$ErrorActionPreference = "Stop"

$JavaHome = "C:\Users\nesvi\tools\jdk-21-portable\jdk-21.0.11+10"
$MavenHome = "C:\Users\nesvi\tools\apache-maven-3.9.16"

if (Test-Path $JavaHome) {
    $env:JAVA_HOME = $JavaHome
    $env:Path = "$JavaHome\bin;$env:Path"
}

if (Test-Path $MavenHome) {
    $env:MAVEN_HOME = $MavenHome
    $env:Path = "$MavenHome\bin;$env:Path"
}

if (!(Test-Path ".\tools")) {
    New-Item -ItemType Directory ".\tools" | Out-Null
}

Push-Location ".\tools"

if (!(Test-Path ".\creadur-whisker")) {
    git clone https://gitbox.apache.org/repos/asf/creadur-whisker.git
}

Push-Location ".\creadur-whisker"

Write-Host "Ð¡Ð¾Ð±Ð¸Ñ€Ð°ÑŽ Apache Whisker Ð¸Ð· Ð¸ÑÑ…Ð¾Ð´Ð½Ð¸ÐºÐ¾Ð²..." -ForegroundColor Green
mvn -DskipTests install

Pop-Location
Pop-Location

Write-Host "Ð¡Ð½Ð¾Ð²Ð° Ð·Ð°Ð¿ÑƒÑÐºÐ°ÑŽ Ð¿Ñ€Ð¾ÐµÐºÑ‚..." -ForegroundColor Green
mvn -U package