﻿# Analiza prawno-techniczna projektu

## Temat

Automatyczne generowanie dokumentacji licencyjnej aplikacji z wykorzystaniem Apache Whisker.

## Cel projektu

Celem projektu jest pokazanie, jak Apache Whisker moÅ¼e wspieraÄ‡ proces license compliance, czyli zgodnoÅ›ci aplikacji z wymaganiami licencji open source.

Projekt nie polega na tworzeniu nowej licencji. Projekt pokazuje, jak uporzÄ…dkowaÄ‡ informacje o plikach, autorach, organizacjach i licencjach, a nastÄ™pnie wygenerowaÄ‡ dokumentacjÄ™ licencyjnÄ….

## Problem

Nowoczesna aplikacja zwykle zawiera kod wÅ‚asny oraz komponenty third-party. KaÅ¼dy komponent moÅ¼e mieÄ‡ innÄ… licencjÄ™ i inne obowiÄ…zki.

GÅ‚Ã³wne problemy:

1. Trudno rÄ™cznie Å›ledziÄ‡ wszystkie pliki i ich licencje.
2. Åatwo zapomnieÄ‡ o copyright notice.
3. Åatwo pominÄ…Ä‡ tekst licencji.
4. NiektÃ³re licencje wymagajÄ… dodatkowych informacji NOTICE.
5. Licencje copyleft, np. GPL, mogÄ… tworzyÄ‡ ryzyko dla aplikacji zamkniÄ™tych.
6. Dokumentacja moÅ¼e staÄ‡ siÄ™ nieaktualna po dodaniu nowej zaleÅ¼noÅ›ci.

## Licencje w projekcie

MIT License jest licencjÄ… permissive. Pozwala zwykle na uÅ¼ycie, modyfikacjÄ™ i dystrybucjÄ™ kodu, ale wymaga zachowania copyright notice oraz tekstu licencji.

Apache License 2.0 takÅ¼e jest licencjÄ… permissive, ale zawiera bardziej rozbudowane postanowienia, m.in. dotyczÄ…ce patentÃ³w i informacji NOTICE.

GPL zostaÅ‚a pokazana jako przykÅ‚ad ryzyka. Plik GPL-like nie jest czÄ™Å›ciÄ… dystrybucji i nie jest wpisany do descriptor.xml. SÅ‚uÅ¼y tylko do omÃ³wienia problemu copyleft.

## Rola Apache Whisker

Apache Whisker nie zastÄ™puje prawnika i nie wybiera licencji za autora. NarzÄ™dzie pomaga utrzymywaÄ‡ dokumentacjÄ™ licencyjnÄ… przez plik descriptor.xml.

W descriptor.xml opisujemy:

- licencje,
- organizacje,
- gÅ‚Ã³wnÄ… licencjÄ™ projektu,
- gÅ‚Ã³wnego autora/organizacjÄ™,
- katalogi i pliki aplikacji,
- powiÄ…zanie plikÃ³w z licencjami.

## Wnioski

Apache Whisker jest uÅ¼yteczny jako narzÄ™dzie license compliance. NajwiÄ™ksza korzyÅ›Ä‡ polega na tym, Å¼e informacje prawne sÄ… uporzÄ…dkowane w jednym pliku descriptor.xml, a dokumentacja moÅ¼e byÄ‡ generowana automatycznie w procesie build.