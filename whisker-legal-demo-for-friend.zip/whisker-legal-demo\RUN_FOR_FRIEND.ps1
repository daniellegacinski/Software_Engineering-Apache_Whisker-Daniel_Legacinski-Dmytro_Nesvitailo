# RUN_FOR_FRIEND.ps1
# Universal script for running Apache Whisker demo on another Windows computer.
# It installs portable JDK 21 and Maven into user's home folder if needed,
# then runs Maven to generate legal documentation.

$ErrorActionPreference = "Stop"

Write-Host "=== Apache Whisker Legal Demo ===" -ForegroundColor Cyan

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

$ToolsDir = Join-Path $env:USERPROFILE "tools"
$JdkExtractDir = Join-Path $ToolsDir "jdk-21-portable"
$MavenVersion = "3.9.16"
$MavenHome = Join-Path $ToolsDir "apache-maven-$MavenVersion"

if (!(Test-Path $ToolsDir)) {
    New-Item -ItemType Directory -Path $ToolsDir | Out-Null
}

# ------------------------------------------------------------
# 1. Portable JDK 21
# ------------------------------------------------------------

$JavaExe = $null

if (Test-Path $JdkExtractDir) {
    $JavaExe = Get-ChildItem -Path $JdkExtractDir -Recurse -Filter "java.exe" -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -like "*\bin\java.exe" } |
        Select-Object -First 1
}

if ($null -eq $JavaExe) {
    Write-Host "Downloading portable JDK 21..." -ForegroundColor Cyan

    if (Test-Path $JdkExtractDir) {
        Remove-Item $JdkExtractDir -Recurse -Force
    }

    New-Item -ItemType Directory -Path $JdkExtractDir | Out-Null

    $JdkZip = Join-Path $env:TEMP "temurin-jdk21.zip"
    $JdkUrl = "https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse?project=jdk"

    Invoke-WebRequest -UseBasicParsing -Uri $JdkUrl -OutFile $JdkZip
    Expand-Archive -Path $JdkZip -DestinationPath $JdkExtractDir -Force

    $JavaExe = Get-ChildItem -Path $JdkExtractDir -Recurse -Filter "java.exe" |
        Where-Object { $_.FullName -like "*\bin\java.exe" } |
        Select-Object -First 1
}

if ($null -eq $JavaExe) {
    throw "Java was not found after installation."
}

$JavaHome = Split-Path -Parent (Split-Path -Parent $JavaExe.FullName)

# ------------------------------------------------------------
# 2. Portable Maven
# ------------------------------------------------------------

if (!(Test-Path $MavenHome)) {
    Write-Host "Downloading Apache Maven $MavenVersion..." -ForegroundColor Cyan

    $MavenZip = Join-Path $env:TEMP "apache-maven-$MavenVersion-bin.zip"
    $MavenUrl = "https://archive.apache.org/dist/maven/maven-3/$MavenVersion/binaries/apache-maven-$MavenVersion-bin.zip"

    Invoke-WebRequest -UseBasicParsing -Uri $MavenUrl -OutFile $MavenZip
    Expand-Archive -Path $MavenZip -DestinationPath $ToolsDir -Force
}

if (!(Test-Path $MavenHome)) {
    throw "Maven was not found after installation."
}

# ------------------------------------------------------------
# 3. Configure current PowerShell session
# ------------------------------------------------------------

$env:JAVA_HOME = $JavaHome
$env:MAVEN_HOME = $MavenHome
$env:Path = "$JavaHome\bin;$MavenHome\bin;$env:Path"

Write-Host ""
Write-Host "Java:" -ForegroundColor Green
java -version

Write-Host ""
Write-Host "Maven:" -ForegroundColor Green
mvn -version

# ------------------------------------------------------------
# 4. Run Apache Whisker
# ------------------------------------------------------------

Write-Host ""
Write-Host "Cleaning old generated files..." -ForegroundColor Cyan

if (Test-Path ".\generated-legal-docs") {
    Remove-Item ".\generated-legal-docs" -Recurse -Force
}

Write-Host ""
Write-Host "Running Apache Whisker through Maven..." -ForegroundColor Green
mvn -U package

Write-Host ""
Write-Host "Generated files:" -ForegroundColor Green

if (Test-Path ".\generated-legal-docs") {
    Get-ChildItem ".\generated-legal-docs" -Recurse | Format-Table FullName, Length
    Invoke-Item ".\generated-legal-docs"
} else {
    Write-Host "generated-legal-docs folder was not created." -ForegroundColor Red
}

Write-Host ""
Write-Host "DONE." -ForegroundColor Green