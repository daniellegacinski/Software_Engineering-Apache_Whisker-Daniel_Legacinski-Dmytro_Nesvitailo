﻿/*
 * Ten plik NIE jest czÄ™Å›ciÄ… dystrybucji.
 * SÅ‚uÅ¼y tylko jako przykÅ‚ad ryzyka copyleft/GPL w raporcie.
 */

int risky_example() {
    return 1;
}