﻿// Example third-party helper
// Copyright (c) 2023 Example MIT Author
// License: MIT

function normalizeText(value) {
    return String(value).trim().toLowerCase();
}