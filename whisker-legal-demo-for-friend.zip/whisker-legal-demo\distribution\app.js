﻿// Copyright (c) 2026 Dima Nesvitajlo
// License: MIT

function showLicenseInfo() {
    document.getElementById("output").textContent =
        "Aplikacja zawiera pliki wÅ‚asne oraz komponenty third-party.\n" +
        "Apache Whisker generuje dokumentacjÄ™ licencyjnÄ… na podstawie descriptor.xml.";
}