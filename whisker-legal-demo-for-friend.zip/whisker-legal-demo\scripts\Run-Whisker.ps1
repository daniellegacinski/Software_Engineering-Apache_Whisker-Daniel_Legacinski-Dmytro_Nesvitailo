﻿$ErrorActionPreference = "Stop"

$JavaHome = "C:\Users\nesvi\tools\jdk-21-portable\jdk-21.0.11+10"
$MavenHome = "C:\Users\nesvi\tools\apache-maven-3.9.16"

if (Test-Path $JavaHome) {
    $env:JAVA_HOME = $JavaHome
    $env:Path = "$JavaHome\bin;$env:Path"
}

if (Test-Path $MavenHome) {
    $env:MAVEN_HOME = $MavenHome
    $env:Path = "$MavenHome\bin;$env:Path"
}

Write-Host "Java:" -ForegroundColor Cyan
java -version

Write-Host ""
Write-Host "Maven:" -ForegroundColor Cyan
mvn -version

if (Test-Path ".\generated-legal-docs") {
    Remove-Item ".\generated-legal-docs" -Recurse -Force
}

Write-Host ""
Write-Host "Ð—Ð°Ð¿ÑƒÑÐºÐ°ÑŽ Apache Whisker Ñ‡ÐµÑ€ÐµÐ· Maven..." -ForegroundColor Green
mvn -U package

Write-Host ""
Write-Host "Ð ÐµÐ·ÑƒÐ»ÑŒÑ‚Ð°Ñ‚:" -ForegroundColor Green

if (Test-Path ".\generated-legal-docs") {
    Get-ChildItem ".\generated-legal-docs" -Recurse | Format-Table FullName, Length
} else {
    Write-Host "ÐŸÐ°Ð¿ÐºÐ° generated-legal-docs Ð½Ðµ ÑÐ¾Ð·Ð´Ð°Ð½Ð°." -ForegroundColor Red
}

Write-Host ""
Write-Host "Ð•ÑÐ»Ð¸ Maven Ð½Ðµ Ð½Ð°Ð¹Ð´Ñ‘Ñ‚ apache-whisker-maven-plugin, Ð·Ð°Ð¿ÑƒÑÑ‚Ð¸:"
Write-Host ".\scripts\Build-Whisker-From-Source.ps1"